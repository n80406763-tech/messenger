const { Router } = require("express");
const router = Router();
const jwt = require("jsonwebtoken");
const config = require("config");
const secret = config.get("secret");
const Contact = require("../models/Contact");
const User = require("../models/User");
const Msg = require("../models/Msg");
const Dialog = require("../models/Dialog");

router.post("/list", async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ message: "Token is required" });
    }

    const decode = jwt.verify(token, secret);
    const user_from_id = decode.user_id;

    if (!user_from_id) {
      return res.status(401).json({ message: "Token doesn't contain user_id" });
    }

    const dialogs_from = await Dialog.find({ user_from_id });
    const dialogs_to = await Dialog.find({ user_to_id: user_from_id });

    const list = [...dialogs_from, ...dialogs_to];

    let dialogNew = [];

    for (const dialog of list) {
      if (!dialog?.user_to_id) {
        return res.status(500).json({
          message: `Contact ${contact._id} has no user_to_id`,
          error: e.message,
        });
      }
      let user;
      if (dialog.user_from_id == user_from_id) {
        user = await User.findById(dialog.user_to_id);
      } else {
        user = await User.findById(dialog.user_from_id);
      }
      let contact;
      if (dialog.user_from_id == user_from_id) {
        contact = await Contact.findOne({
          user_from_id,
          user_to_id: dialog.user_to_id,
        });
      }
      console.log(contact);
      if (!user) {
        return res.status(500).json({
          message: `User ${dialog.user_to_id} not found`,
          error: e.message,
        });
      }
      const msg = await Msg.findOne({ dialog_id: dialog._id }).sort({
        _id: -1,
      });
      const msgNotReaded = await Msg.find({
        dialog_id: dialog._id,
        read: false,
        user_to_id: user_from_id,
      });
      //   const msgNotReaded = msg2.filter((item) => item.read === false);

      const dialogAdd = {
        _id: dialog._id,
        user_from_id: dialog.user_from_id,
        user_to_id: dialog.user_to_id,
        name: contact ? contact.contactName : user?.name,
        contact: contact ? true : false,
        trash: dialog.trash,
        avatar: user.avatar,
        msgLast: msg ? msg.msg : "No messages",
        msgTime: msg ? msg.dateCreate : "",
        msgNotReaded: msgNotReaded.length,
      };

      dialogNew.push(dialogAdd);
    }

    // if (contactsNew.length > 0) {
    //   contactsNew.sort((a, b) => {
    //     if (a.msgTime > b.msgTime) return -1;
    //     return 1;
    //   });
    // }
    return res.status(200).json({ list: dialogNew });
  } catch (e) {
    console.error("Error in contacts/list:", e);
    return res.status(500).json({
      message: "Internal server error",
      error: e.message,
    });
  }
});

router.post("/create", async (req, res) => {
  try {
    const { token, user_to_id } = req.body;
    if (!token) {
      return res.status(400).json({ message: "Token is required" });
    }

    const decode = jwt.verify(token, secret);
    const user_from_id = decode.user_id;

    if (!user_from_id) {
      return res.status(401).json({ message: "Token doesn't contain user_id" });
    }
    const dialogExistFrom = await Dialog.findOne({
      user_from_id,
      user_to_id,
      trash: false,
    });
    const dialogExistTo = await Dialog.findOne({
      user_from_id: user_to_id,
      user_to_id: user_from_id,
      trash: false,
    });
    if (dialogExistFrom || dialogExistTo) {
      const data = dialogExistTo ? dialogExistTo : dialogExistFrom;
      return res
        .status(206)
        .json({ code: 101, message: "dialog alredy exists", id: data._id });
    }
    const dialog = await Dialog.create({
      user_from_id,
      user_to_id,
      trash: false,
    });

    return res.status(200).json({ id: dialog._id });
  } catch (e) {
    console.error("Error in contacts/list:", e);
    return res.status(500).json({
      message: "Internal server error",
      error: e.message,
    });
  }
});

module.exports = router;
