const { Router } = require("express");
const router = Router();
const jwt = require("jsonwebtoken");
const config = require("config");
const secret = config.get("secret");
const Contact = require("../models/Contact");
const User = require("../models/User");
const Msg = require("../models/Msg");
const Dialog = require("../models/Dialog");

router.post("/list", async (req, res) => {
  try {
    const { token, dialog_id } = req.body;

    const decode = jwt.verify(token, secret);
    const user_from_id = decode.user_id;

    if (!user_from_id)
      return res.status(206).json({ message: "Token error", error: e });

    const dialog = await Dialog.findById(dialog_id);
    let interlocutor_id = dialog.user_to_id;
    if (user_from_id == dialog.user_to_id) {
      interlocutor_id = dialog.user_from_id;
    }
    const user = await User.findById(interlocutor_id);

    const contact = await Contact.findOne({
      user_from_id,
      user_to_id: interlocutor_id,
    });

    let name = user.name;
    if (contact) {
      name = contact.contactName;
    }

    const msgDialog = await Msg.find({ dialog_id });

    // 1. объединить 2 массива +
    // 2. сотрировку по дате

    await Msg.updateMany(
      {
        user_from_id: interlocutor_id,
        user_to_id: user_from_id,
      },
      { $set: { read: true } },
    );

    msgDialog.sort((a, b) => {
      if (a.dateCreate < b.dateCreate) {
        return -1;
      }
      return 1;
    });

    return res.status(200).json({
      list: msgDialog,
      avatar: user.avatar,
      name,
      contact: contact ? true : false,
    });
  } catch (e) {
    return res.status(500).json({ message: "Fetch error: ", error: e });
  }
});

router.post("/create", async (req, res) => {
  try {
    const { token, user_to_id, msg } = req.body;

    const decode = jwt.verify(token, secret);
    const user_from_id = decode.user_id;

    if (!user_from_id)
      return res.status(500).json({
        message: "Token error: decoding failed, msg/create",
        error: e,
      });

    const dateCreate = new Date();
    let dialog;
    const dialogFrom = await Dialog.findOne({ user_from_id, user_to_id });
    const dialogTo = await Dialog.findOne({
      user_to_id: user_from_id,
      user_from_id: user_to_id,
    });

    if (!dialogFrom && !dialogTo) {
      dialog = await Dialog.create({ user_from_id, user_to_id });
    } else {
      dialog = dialogFrom ? dialogFrom : dialogTo;
    }

    const msg_to_return = await Msg.create({
      user_from_id,
      user_to_id,
      msg,
      dateCreate,
      dialog_id: dialog._id,
    });

    return res.status(200).json({ msg_to_return });
  } catch (e) {
    return res.status(500).json({
      message: "Fetch error: something wrong in msg/create",
      error: e,
    });
  }
});

module.exports = router;
