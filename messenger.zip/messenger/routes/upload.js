const { Router } = require("express");
const router = Router();
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    const ext = file.originalname.substring(
      file.originalname.lastIndexOf("."),
      file.originalname.length,
    );
    const ran = Math.floor(
      10000 + Math.random() * 10000 + Math.random() * 10000,
    );
    cb(null, Date.now() + "_" + ran + ext);
  },
});
const upload = multer({
  storage: storage,
});

router.post("/upload", upload.single("image"), async (req, res, next) => {
  try {
    console.log(req.file);
    res.status(200).json({ link: req.file.path });
  } catch (e) {
    res.status(500).json({ message: "Something went wrong" });
  }
});
module.exports = router;
