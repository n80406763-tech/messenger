const { Router } = require("express");
const router = Router();
const jwt = require("jsonwebtoken");
const config = require("config");
const secret = config.get("secret");
const Contact = require("../models/Contact");
const User = require("../models/User");
const Msg = require("../models/Msg");
const Dialog = require("../models/Dialog");

router.post("/list", async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ message: "Token is required" });
    }

    const decode = jwt.verify(token, secret);
    const user_from_id = decode.user_id;

    if (!user_from_id) {
      return res.status(401).json({ message: "Token doesn't contain user_id" });
    }

    const contacts = await Contact.find({ user_from_id });
    const dialogs_from = await Dialog.find({ user_from_id });
    const dialogs_to = await Dialog.find({ user_to_id: user_from_id });

    const list = [...contacts, ...dialogs_from, ...dialogs_to];

    let contactsNew = [];

    for (const contact of list) {
      if (!contact?.user_to_id) {
        return res.status(500).json({
          message: `Contact ${contact._id} has no user_to_id`,
          error: e.message,
        });
      }
      let user;
      if (contact.user_from_id == user_from_id) {
        user = await User.findById(contact.user_to_id);
      } else {
        user = await User.findById(contact.user_from_id);
      }

      if (!user) {
        return res.status(500).json({
          message: `User ${contact.user_to_id} not found`,
          error: e.message,
        });
      }
      const msg1 = await Msg.find({
        user_from_id,
        user_to_id: user._id,
      });
      const msg2 = await Msg.find({
        user_from_id: user._id,
        user_to_id: user_from_id,
      });
      console.log(msg1, msg2);
      const msgNotReaded = msg2.filter((item) => item.read === false);
      const allMsg = [...msg1, ...msg2];
      console.log(user_from_id, contact._id);
      if (allMsg.length > 0) {
        allMsg.sort((a, b) => {
          if (a.dateCreate < b.dateCreate) {
            return -1;
          }
          return 1;
        });
      }

      console.log(allMsg);

      const contactAdd = {
        _id: contact._id,
        link: user._id,
        user_from_id: contact.user_from_id,
        user_to_id: contact.user_to_id,
        contactName: contact.contactName ? contact.contactName : user?.name,
        contact: contact.contactName ? true : false,
        trash: contact.trash,
        avatar: user.avatar,
        msgLast:
          allMsg.length > 0 ? allMsg[allMsg.length - 1].msg : "No messages",
        msgTime: allMsg.length > 0 ? allMsg[allMsg.length - 1].dateCreate : "",
        msgNotReaded: msgNotReaded.length,
      };

      contactsNew.push(contactAdd);
    }

    if (contactsNew.length > 0) {
      contactsNew.sort((a, b) => {
        if (a.msgTime > b.msgTime) return -1;
        return 1;
      });
    }
    return res.status(200).json({ list: contactsNew });
  } catch (e) {
    console.error("Error in contacts/list:", e);
    return res.status(500).json({
      message: "Internal server error",
      error: e.message,
    });
  }
});

router.post("/create", async (req, res) => {
  try {
    const { token, contact_id, contactName } = req.body;

    let decode;
    try {
      decode = jwt.verify(token, secret);
    } catch (e) {
      return res.status(401).json({ message: "Invalid token", error: e });
    }

    const user_from_id = decode.user_id;

    if (!user_from_id) {
      return res.status(401).json({ message: "Token doesn't contain user_id" });
    }

    if (user_from_id === contact_id) {
      return res
        .status(400)
        .json({ message: "Cannot add yourself as contact" });
    }

    const userToAdd = await User.findById(contact_id);
    console.log(contact_id);
    if (!userToAdd) {
      return res.status(404).json({ message: "User to add not found" });
    }

    const existingContact = await Contact.findOne({
      user_from_id,
      user_to_id: contact_id,
    });

    if (existingContact) {
      return res.status(409).json({
        message: "Contact already exists",
        contact: existingContact,
      });
    }

    // Создание нового контакта
    const newContact = await Contact.create({
      user_from_id,
      user_to_id: contact_id,
      contactName,
    });

    return res.status(201).json({
      message: "Contact created successfully",
      contact: newContact,
    });
  } catch (e) {
    console.error("Error in contacts/create:", e);
    return res.status(500).json({
      message: "Internal server error",
      error: e.message,
    });
  }
});

module.exports = router;
