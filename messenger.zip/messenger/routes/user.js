const { Router } = require("express");
const router = Router();
const User = require("../models/User");
// const nodemailer = require("nodemailer");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const config = require("config");
const Contact = require("../models/Contact");
const { default: Avatar } = require("../client/src/components/avatar");
const secret = config.get("secret");

router.post("/code", async (req, res) => {
  try {
    const { email } = req.body;

    // const transporter = nodemailer.createTransport({
    //   service: "gmail",
    //   auth: {
    //     user: "trodat4642@gmail.com",
    //     pass: "cbkfLtkf108",
    //   },
    // });

    // const transporter = nodemailer.createTransport({
    //   host: "smtp.ethereal.email",
    //   port: 587,
    //   auth: {
    //     user: "elmore9@ethereal.email",
    //     pass: "yWeWzgwrgb2aAmxRha",
    //   },
    // });
    // const transporter = nodemailer.createTransport({
    //   host: "localhost",
    //   port: 25,
    //   tls: {
    //     rejectUnauthorized: false,
    //   },
    // });

    // const mailOptions = {
    //   to: "vp.collapse@gmail.com",
    //   from: "elmore9@ethereal.email",
    //   subject: "Auth code",
    //   text: "code: 123456",
    // };

    // transporter.sendMail(mailOptions, (e, info) => {
    //   if (e) {
    //     console.log("Error sending mail", e);
    //   } else {
    //     console.log("Email sent", info.response);
    //   }
    // });
    res.status(200).json({ message: "Sending mail" });
  } catch (e) {
    res.status(500).json({ message: "Fetch error", error: e });
  }
});

router.post("/update", async (req, res) => {
  try {
    const { token, name, avatar } = req.body;

    const decode = jwt.verify(token, secret);
    const user_id = decode.user_id;

    if (!user_id)
      return res.status(500).json({ message: "Token error", error: e });

    await User.findByIdAndUpdate(user_id, {
      avatar,
      name,
    });

    return res.status(200).json({ message: "Update" });
  } catch (e) {
    res.status(500).json({ message: "Fetch error", error: e });
  }
});

router.post("/reg", async (req, res) => {
  try {
    const { email, pass, name, short } = req.body;

    const hashPass = await bcrypt.hash(pass, 12);

    // 1. проверяем уникальность email
    const emailExist = await User.findOne({ email });
    if (emailExist) {
      return res
        .status(204)
        .json({ code: 201, message: "This email already exists" });
    }
    const shortExist = await User.findOne({ shortId: short });
    if (shortExist) {
      return res
        .status(204)
        .json({ code: 202, message: "This shortId already exists" });
    }

    const user = await User.create({
      email,
      pass: hashPass,
      name,
      shortId: short,
    });

    const user_id = user._id;
    const token = jwt.sign({ user_id }, secret);

    return res.status(200).json({ token, name });
  } catch (e) {
    res.status(500).json({ message: "Fetch error", error: e });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, pass } = req.body;

    const user = await User.findOne({ email });

    if (!user) return res.status(204).json({ msg: "User doesn't exist" });

    const isPassCorrect = await bcrypt.compare(pass, user.pass);
    if (!isPassCorrect)
      return res.status(204).json({ msg: "Invalid password" });

    const user_id = user._id;
    const token = jwt.sign({ user_id }, secret);
    if (token == "undefined" || !token) {
      res.status(500).json({ message: "invalid token!", error: e });
    }
    return res
      .status(200)
      .json({ token, name: user.name, avatar: user.avatar });
  } catch (e) {
    res.status(500).json({ message: "Fetch error", error: e });
  }
});

router.post("/search", async (req, res) => {
  try {
    const { token, short } = req.body;

    const decode = jwt.verify(token, secret);
    const user_from_id = decode.user_id;

    if (!user_from_id) {
      return res.status(401).json({ message: "invalid token" });
    }

    // const users = await User.find({ shortId: { $regex: short } });
    const user = await User.findOne({ shortId: short });
    if (!user) {
      return res
        .status(206)
        .json({ code: 201, search: {}, message: "nothing found" });
    }

    if (user._id == user_from_id) {
      return res
        .status(206)
        .json({ code: 202, search: {}, message: "you cant find yourself" });
    }

    let result = {};
    let code = 202;
    if (user) {
      result = {
        _id: user._id,
        shortId: user.shortId,
        avatar: user.avatar,
      };
      code = 201;
    }
    // const contacts = await Contact.find({ user_from_id });
    // let usersResult = [];
    // users.forEach((user) => {
    //   if (user._id != user_from_id) {
    //     console.log(user._id, contacts);
    //     const i = contacts.findIndex(
    //       (contact) => contact.user_to_id == user._id,
    //     );

    //     if (i === -1) {
    //       usersResult.push(user);
    //     }
    //   }
    // });

    return res.status(200).json({ code, search: result });
  } catch (e) {
    res.status(500).json({ message: "Fetch error", error: e });
  }
});

module.exports = router;
