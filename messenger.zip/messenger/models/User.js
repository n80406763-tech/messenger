const { Schema, model } = require('mongoose');

const schema = new Schema({
  email: { type: String, require: true },
  pass: { type: String, require: true },
  name: { type: String, require: true },
  dateReg: { type: Date },
  shortId: { type: String, require: true },
  avatar: { type: String },
});

module.exports = model('User', schema);
