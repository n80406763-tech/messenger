const { Schema, model } = require("mongoose");

const schema = new Schema({
  user_from_id: { type: String, require: true },
  user_to_id: { type: String, require: true },
  trash: { type: Boolean, default: false },
});

module.exports = model("Dialog", schema);
