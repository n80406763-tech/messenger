const { Schema, model } = require("mongoose");

const schema = new Schema({
  user_from_id: { type: String, require: true },
  user_to_id: { type: String, require: true },
  dateCreate: { type: Date, require: true },
  msg: { type: String, require: true },
  read: { type: Boolean, default: false },
  trash: { type: Boolean, default: false },
  dialog_id: { type: String, require: true },
});

module.exports = model("Msg", schema);
