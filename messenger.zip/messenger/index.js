const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const path = require("path");

const PORT = 5001;

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(cors());

app.use("/api/user", require("./routes/user"));
app.use("/api/contacts", require("./routes/contacts"));
app.use("/api/dialogs", require("./routes/dialogs"));
app.use("/api/msg", require("./routes/msg"));
app.use("/api/upload", require("./routes/upload"));

app.use("/uploads", express.static(path.join(__dirname, "uploads")));
async function start() {
  try {
    await mongoose.connect("mongodb://localhost:27017/nikita");

    app.listen(PORT, () => {
      console.log("app has been started on port", PORT);
    });
  } catch (e) {
    console.log("Server Error - index.js", e.message);
    process.exit(1);
  }
}

start();
