import { useRoutes, Navigate } from "react-router-dom";
import Reg from "./components/Reg";
import Login from "./components/Login";
import { useState } from "react";
import Main from "./pages/Main";

const Routes = () => {
  const [token] = useState(localStorage.getItem("token"));
  let [userToken] = "true";
  if (token == "undefined" || !token) {
    userToken = false;
  }

  const routes = [
    {
      path: "/",
      children: [
        {
          path: "reg",
          element: userToken ? <Navigate to="/msg/0" /> : <Reg />,
        },
        {
          path: "login",
          element: userToken ? <Navigate to="/msg/0" /> : <Login />,
        },
        {
          path: "/",
          element: <Navigate to="/msg/0" />,
        },
        {
          path: "msg/:dialog_id",
          element: userToken ? <Main /> : <Navigate to="/login" />,
        },
            {
          path: "/msg/",
          element: <Navigate to="/msg/0" />,
        },
      ],
    },
  ];
  return useRoutes(routes);
};

export default Routes;
