import axios from "axios";

const API_URL = "http://185.251.90.40:5001/";
const API = axios.create({ baseURL: API_URL });
const UPLOAD = axios.create({ baseURL: API_URL });

UPLOAD.interceptors.request.use((req) => {
  req.headers.ContentType = "multipart/form-data";
  return req;
});

// user
export const regAPI = (formData) => API.post("/api/user/reg", formData);
export const loginAPI = (formData) => API.post("/api/user/login", formData);
export const searchAPI = (formData) => API.post("/api/user/search", formData);
export const updateAPI = (formData) => API.post("/api/user/update", formData);
// contacts
export const contactsListAPI = (formData) =>
  API.post("/api/contacts/list", formData);
export const contactCreateAPI = (formData) =>
  API.post("/api/contacts/create", formData);
// dialogs
export const dialogsListAPI = (formData) =>
  API.post("/api/dialogs/list", formData);
export const dialogsCreateAPI = (formData) =>
  API.post("/api/dialogs/create", formData);
// msg
export const msgListAPI = (formData) => API.post("/api/msg/list", formData);
export const msgCreateAPI = (formData) => API.post("/api/msg/create", formData);
//upload
export const uploadAPI = (imageData) =>
  UPLOAD.post("/api/upload/upload", imageData);
