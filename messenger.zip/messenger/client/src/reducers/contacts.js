const contactsReducer = (state = { contactsData: null }, action) => {
  switch (action.type) {
    case 'CONTACTS_LIST':
      return { ...state, contactsData: action?.data?.list };
    case 'CONTACTS_SEARCH':
      return { ...state, contactsSearch: action?.data?.search };
    default:
      return state;
  }
};

export default contactsReducer;
