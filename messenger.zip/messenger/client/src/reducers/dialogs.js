const dialogsReducer = (state = { dialogsData: null }, action) => {
  switch (action.type) {
    case "DIALOGS_LIST":
      return { ...state, dialogsData: action?.data?.list };
    default:
      return state;
  }
};

export default dialogsReducer;
