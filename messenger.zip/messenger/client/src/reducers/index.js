import { combineReducers } from "redux";

import contacts from "./contacts";
import msg from "./msg";
import upload from "./upload";
import dialogs from "./dialogs";
import user from "./user";
export const reducers = combineReducers({
  contacts,
  msg,
  upload,
  dialogs,
  user,
});
