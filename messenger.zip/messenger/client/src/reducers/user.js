const userReducer = (state = { userData: null }, action) => {
  switch (action.type) {
    case "USER_SEARCH":
      return { ...state, userData: action?.data?.search };
    default:
      return state;
  }
};

export default userReducer;
