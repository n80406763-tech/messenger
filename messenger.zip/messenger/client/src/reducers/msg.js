const msgReducer = (state = { msgData: null }, action) => {
  switch (action.type) {
    case "MSG_LIST":
      return {
        ...state,
        msgContact: action?.data?.contact,
        msgData: action?.data?.list,
        msgName: action?.data?.name,
        msgAvatar: action?.data?.avatar,
      };
    default:
      return state;
  }
};

export default msgReducer;
