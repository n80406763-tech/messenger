const uploadReducer = (state = { imagesData: null }, action) => {
  switch (action.type) {
    case "UPLOAD_IMAGE":
      return { ...state, imagesData: action?.link };
    default:
      return state;
  }
};

export default uploadReducer;
