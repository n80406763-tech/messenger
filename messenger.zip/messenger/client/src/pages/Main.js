import { Box, Button, Typography } from "@mui/material";
import Logo from "../components/Logo/Logo.js";
import { FiSearch } from "react-icons/fi";

import { useDispatch, useSelector } from "react-redux";
import { getContactsList, createContact } from "../actions/contacts.js";
import { getMsgList } from "../actions/msg.js";
import { useEffect, useState, useRef } from "react";
import { Link, useParams } from "react-router";
import { LuMessageCircleOff } from "react-icons/lu";
import { Formik } from "formik";
import { createMsg } from "../actions/msg.js";
import UserSearch from "../components/UserSearch.js";
import Modal from "@mui/material/Modal";
import Settings from "../components/Settings.js";
import Ava from "../components/Ava.js";
import UserItem from "../components/UserItem.js";
import { getDialogsList } from "../actions/dialog.js";
import Text from "../components/Text.js";
const DOMEN = "http://185.251.90.40:5001/";

const SearchItem = (props) => {
  return (
    <Link to={"/msg/" + props.user_to_id}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          height: "110px",
          padding: "0 15px",
          borderBottom: "1px solid #393636",
          "&:hover": {
            cursor: "pointer",
          },
        }}>
        <Ava link={DOMEN + props.img} size={80} />
        <Typography
          sx={{
            color: "#fff",
            fontSize: "16px",
            fontWeight: "600",
            marginLeft: "12px",
            width: "170px",
          }}>
          {props.short}
        </Typography>
      </Box>
    </Link>
  );
};

const MsgItem = (props) => {
  // console.log(DOMEN + props.img);
  const t = props.time.split("T")[1].split(":");
  return (
    <Box
      sx={{
        display: "flex",
        margin: "15px 20px",
        justifyContent: props.user ? "flex-start" : "flex-end",
      }}>
      {props.user ? <Ava link={DOMEN + props.avatar} size={40} /> : ""}

      <Box
        sx={{
          marginLeft: "20px",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-end",
        }}>
        <Typography
          sx={{
            padding: "40px 20px",
            backgroundColor: "#1C1D26",
            border: "1px solid #3B3D49",
            borderRadius: props.user ? "20px 0 20px 20px" : "0 20px 20px 20px",
            width: "324px",
            color: "#B5BFD6",
            fontSize: "16px",
          }}>
          {props.msg}
        </Typography>
        <Typography
          sx={{ color: "#B5BFD6", fontSize: "14px", marginTop: "12px" }}>
          {t[0] + ":" + t[1]}
        </Typography>
      </Box>
    </Box>
  );
};

const Msg = (props) => {
  return (
    <Box sx={{ width: "700px" }}>
      {/* Msg Name */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          height: "81px",
          borderBottom: "1px solid #393636",
          width: "100%",
          padding: "0 20px",
          justifyContent: "space-between",
        }}>
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <Ava link={DOMEN + props.avatar} size={50} />
          <Typography
            sx={{ marginLeft: "20px", color: "#B5BFD6", fontSize: "20px" }}>
            {props.name}
          </Typography>
        </Box>
        <Box
          sx={{
            padding: "5px 15px",
            backgroundColor: "#25b366",
            borderRadius: "4px",
            transition: "all 0.3s  ease",
            "&:hover": {
              cursor: "pointer",
              backgroundColor: "#21f17fff",
            },
          }}
          onClick={() => {
            props.handleSearchAddModal();
            console.log(props.avatar);
            props.setSearchAddUser({
              img: props.avatar,
              _id: props.user_to_id,
            });
          }}>
          <Typography sx={{ fontSize: "12px" }}>Add Contact</Typography>
        </Box>
      </Box>
      {/* All msg */}
      <Box
        sx={{
          marginTop: "40px",
          height: "calc(100vh - 281px)",
          overflowY: "scroll",
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-end",
          borderBottom: "1px solid #393636",
        }}>
        {props.list?.map((msg) => (
          <MsgItem
            time={msg.dateCreate}
            key={msg._id}
            msg={msg.msg}
            avatar={props.avatar}
            user={msg?.user_to_id === props.user_to_id ? false : true}
          />
        ))}
      </Box>
      {/* Send msg */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}>
        <Formik
          initialValues={{ msg: "" }}
          onSubmit={(values) => {
            if (values.msg !== "") {
              props.dispatch(
                createMsg({
                  msg: values.msg,
                  user_to_id: props.user_to_id,
                }),
              );
              values.msg = "";
            }
          }}>
          {({ handleChange, handleSubmit, values }) => (
            <>
              <input
                id="msg"
                onChange={handleChange}
                value={values.msg}
                placeholder="Type your Message"
                style={{
                  margin: "20px",
                  height: "60px",
                  width: "500px",
                  border: "none",
                  backgroundColor: "transparent",
                  color: "#B5BFD6",
                  fontSize: "14px",
                }}
              />
              <Box
                onClick={handleSubmit}
                sx={{
                  width: "100px",
                  height: "100px",
                  borderLeft: "1px solid #393636",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  cursor: "pointer",
                }}>
                <svg
                  width="15"
                  height="17"
                  viewBox="0 0 15 17"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M13.608 8.95522L1.51552 15.7188L1.70388 1.86395L13.608 8.95522Z"
                    stroke="#25D366"
                    strokeWidth="2"
                  />
                </svg>
              </Box>
            </>
          )}
        </Formik>
      </Box>
    </Box>
  );
};

const MsgEmpty = () => {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "calc(100% - 460px)",
        height: "calc(100vh - 100px)",
        flexDirection: "column",
      }}>
      <LuMessageCircleOff color="#B5DFD6" size={100} opacity={0.2} />
      <Typography sx={{ marginTop: "20px", color: "#B5BFD6" }}>
        No dialog selected
      </Typography>
    </Box>
  );
};

const Main = () => {
  const dispatch = useDispatch();
  const userSearch = useSelector((state) => state.user);
  const dialogsList = useSelector((state) => state.dialogs);

  const msg = useSelector((state) => state.msg);
  const [searchAddModal, setSearchAddModal] = useState(false);
  const [searchAddUser, setSearchAddUser] = useState("");
  const [contact, setContact] = useState({ name: "", _id: "" });

  console.log(userSearch);

  const handleSearchAddModal = () => {
    if (searchAddModal === true) {
      setSearchAddModal(false);
    } else {
      setSearchAddModal(true);
    }
  };

  const { dialog_id } = useParams();

  useEffect(() => {
    dispatch(getDialogsList());
    dialog_id !== "0" && dispatch(getMsgList({ dialog_id }));
  }, [dialog_id]);

  const [add, setAdd] = useState(false);
  const [search, setSearch] = useState("");

  function handleAdd() {
    if (add === true) {
      setAdd(false);
    } else {
      setAdd(true);
    }
  }
  function handleChange(e) {
    const { id, value } = e.currentTarget;
    setContact({ ...contact, [id]: value });
  }

  const addContact = () => {
    handleAdd();
    handleSearchAddModal();
    setSearch("");
    // dispatch(
    //   createContact({ contactName: contact.name, contact_id: dialog_id }),
    // );
  };

  return (
    <Box
      sx={{
        width: "100%",
        height: "100vh",
        backgroundColor: "#171821",
        display: "flex",
      }}>
      <Modal
        open={searchAddModal}
        onClose={handleSearchAddModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description">
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 500,
            bgcolor: "#272832",
            border: "2px solid #000",
            boxSizing: "border-box",
            borderRadius: "7px",
            boxShadow: 70,
            p: 4,
            display: "flex",
          }}>
          <Box>
            <Ava link={DOMEN + searchAddUser?.img} size={100} />
          </Box>
          <Box>
            <Typography
              sx={{
                paddingLeft: "30px",
                color: "whitesmoke",
                fontSize: "20px",
              }}>
              {"confirm?"}
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "column",
                marginLeft: "30px",
              }}>
              <input
                id="name"
                value={contact.name}
                onChange={handleChange}
                placeholder="Type name for your contact here..."
                style={{
                  border: "none",
                  background: "none",
                  color: "#B5BFD6",
                  borderBottom: "1px solid rgb(91, 96, 107)",
                  padding: "5px 0",
                  width: "200px",
                }}></input>
              <Button
                sx={{ marginLeft: "20px" }}
                variant="contained"
                onClick={addContact}>
                add
              </Button>
            </Box>
          </Box>
        </Box>
      </Modal>
      {/* Left col */}
      <Box
        sx={{
          padding: "15px 12px",
          borderRight: "1px solid #393636",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "center",
        }}>
        <Logo />
        <Settings />
      </Box>
      {/* Right col */}
      <Box sx={{ borderRight: "1px solid #393636" }}>
        {/* Search */}
        <Box
          sx={{
            width: "1100px",
            borderBottom: "1px solid #393636",
            display: "flex",
            alignItems: "center",
            padding: "15px",
            height: "60px",
          }}>
          <FiSearch color="#B5BFD6" size={20} />
        </Box>
        {/* Contacts & Msg */}
        <Box sx={{ display: "flex" }}>
          {/* Contacts */}
          <Box
            sx={{
              width: "400px",
              height: "calc(100vh - 60px)",
              borderRight: "1px solid #393636",
            }}>
            {/* Add contact */}
            <UserSearch
              dispatch={dispatch}
              add={add}
              onClick={handleAdd}
              search={search}
              setSearch={setSearch}
            />
            {/* Contact item */}
            {add ? (
              userSearch?.userData?._id ? (
                <UserItem
                  data={userSearch?.userData}
                  domen={DOMEN}
                  dialog={false}
                />
              ) : (
                <Text text="Not found"></Text>
              )
            ) : (
              dialogsList?.dialogsData?.map((dialog) => (
                <UserItem data={dialog} domen={DOMEN} key={dialog._id} />
              ))
            )}
          </Box>
          {/* Msg */}
          {dialog_id === "0" ? (
            <MsgEmpty />
          ) : (
            <Msg
              msg={msg}
              list={msg.msgData}
              avatar={msg.msgAvatar}
              // user_to_id={user_to_id}
              name={msg.msgName}
              contact={msg.msgContact}
              dispatch={dispatch}
              handleSearchAddModal={handleSearchAddModal}
              setSearchAddUser={setSearchAddUser}
            />
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default Main;
