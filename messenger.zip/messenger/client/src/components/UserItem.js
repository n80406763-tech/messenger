import { Link, Navigate, useNavigate, useParams } from "react-router";
import { Box, Button, Typography } from "@mui/material";
import Ava from "../components/Ava.js";
import { createDialog } from "../actions/dialog.js";

const UserItem = ({ domen, data, dialog = true }) => {
  // props: domen , item
  let t = "";
  const navigate = useNavigate();
  if (dialog && data.msgTime != "") {
    t = data.msgTime.split("T")[1].split(":");
  }
  const handleClick = () => {
    dialog
      ? navigate("/msg/" + data._id)
      : createDialog({ user_to_id: data._id }, navigate);
  };
  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        height: "110px",
        padding: "0 15px",
        justifyContent: dialog ? "space-between" : "start",
        borderBottom: "1px solid #393636",
      }}
      onClick={handleClick}>
      <Ava link={domen + data.avatar} size={80}></Ava>
      <Box sx={{ display: "flex", justifyContent: "space-between" }}>
        <Box sx={{ marginLeft: "12px", width: "170px" }}>
          <Typography
            sx={{ color: "#fff", fontSize: "16px", fontWeight: "600" }}>
            {dialog ? data.name : data.shortId}
          </Typography>
          {dialog && (
            <Typography
              sx={{
                color: "#474B54",
                fontSize: "12px",
                fontWeight: "400",
              }}>
              {data.msgLast}
            </Typography>
          )}
        </Box>
        {dialog && (
          <Box
            sx={{
              width: "100px",
              display: "flex",
              flexDirection: "column",
              alignItems: "end",
            }}>
            <Typography
              sx={{
                color: data.msgNotReaded > 0 ? "#25D366" : "#474B54",
                fontSize: "14px",
              }}>
              {t === "" ? "" : t[0] + ":" + t[1]}
            </Typography>
            {data.msgNotReaded > 0 && (
              <Box
                sx={{
                  width: "20px",
                  height: "20px",
                  borderRadius: "10px",
                  backgroundColor: "#25D366",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: "5px",
                }}>
                <Typography sx={{ color: "#171821", fontSize: "12px" }}>
                  {data.msgNotReaded}
                </Typography>
              </Box>
            )}
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default UserItem;
