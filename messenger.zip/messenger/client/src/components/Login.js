import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { Typography } from "@mui/material";
import { Formik } from "formik";
import { login } from "../actions/user";
import { Link } from "react-router";
const Login = () => {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        flexDirection: "column",
        margin: "0 auto",
        width: 200,
        height: 600,
      }}>
      <Typography variant="h6" color="#212121">
        Login
      </Typography>
      <Formik
        initialValues={{ email: "", pass: "" }}
        onSubmit={(values) =>
          login({
            email: values.email,
            pass: values.pass,
          })
        }>
        {({ handleChange, handleSubmit, values }) => (
          <form method="POST" onSubmit={handleSubmit}>
            <TextField
              name="email"
              id="email"
              label="Email"
              variant="standard"
              onChange={handleChange}
              value={values.email}
            />
            <TextField
              name="pass"
              type="password"
              id="pass"
              label="Pass"
              variant="standard"
              onChange={handleChange}
              value={values.pass}
            />

            <Button
              type="submit"
              variant="contained"
              sx={{ width: 200, marginTop: 2 }}>
              Login
            </Button>
          </form>
        )}
      </Formik>
      <Box sx={{ marginTop: "20px", textAlign: "center" }}>
        <Typography>You havent Account?</Typography>
        <Link to="/reg">
          <Typography>Registration!</Typography>
        </Link>
      </Box>
    </Box>
  );
};

export default Login;
