import { Box } from "@mui/material";

const Avatar = (props) => {
  return (
    <Box
      sx={{
        width: props.size + "px",
        height: props.size + "px",
        borderRadius: "50px",
        backgroundColor: "#15151a",
        overflow: "hidden",
        justifyContent: "center",
        alignItems: "center",
        display: "flex",
      }}>
      <img width={props.size} src={props.link} alt="avatar"></img>
    </Box>
  );
};
export default Avatar;
