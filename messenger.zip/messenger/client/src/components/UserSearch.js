import { Box, Button, Typography } from "@mui/material";
import { FiSearch } from "react-icons/fi";
import { CiCirclePlus } from "react-icons/ci";
import { Formik } from "formik";
import { search } from "../actions/user.js";

const UserSearch = (props) => {
  return (
    <Box
      sx={{
        padding: "15px 10px",
        borderBottom: "1px solid #393636",
        display: "flex",
        alignItems: "center",
        color: "#B5BFD6",
      }}>
      <Box
        onClick={props.onClick}
        sx={{ "&:hover": { color: "#fff", cursor: "pointer" } }}>
        <CiCirclePlus
          size={50}
          style={props.add ? { transform: "rotate(45deg)" } : {}}
        />
      </Box>

      {props.add ? (
        <Box>
          <Typography
            sx={{
              color: "rgb(91, 96, 107)",
              marginLeft: "14px",
              fontSize: "12px",
            }}>
            User search
          </Typography>
          <Formik
            initialValues={{ search: props.search }}
            onSubmit={(values) => {
              if (values.search !== "") {
                props.dispatch(
                  search({
                    short: values.search,
                  }),
                );
                props.setSearch(values.search);
              }
            }}>
            {({ handleChange, handleSubmit, values }) => (
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  marginLeft: "14px",
                }}>
                <form action="POST" onSubmit={handleSubmit}>
                  <input
                    onChange={handleChange}
                    value={values.search}
                    id="search"
                    style={{
                      border: "none",
                      background: "none",
                      color: "#B5BFD6",
                      borderBottom: "1px solid rgb(91, 96, 107)",
                      padding: "5px 0",
                      width: "200px",
                    }}
                  />
                  <Button type="submit" sx={{ minWidth: "30px" }}>
                    <FiSearch color="#B5BFD6" />
                  </Button>
                </form>
              </Box>
            )}
          </Formik>
        </Box>
      ) : (
        <Typography sx={{ marginLeft: "14px" }}>User search</Typography>
      )}
    </Box>
  );
};
export default UserSearch;
