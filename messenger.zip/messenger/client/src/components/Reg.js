import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { Typography } from "@mui/material";
import { Formik } from "formik";
import { register } from "../actions/user";
import { Link } from "react-router";
const Reg = () => {
  // const [enterCode, setEnterCode] = useState(false);

  // const clickReg = () => {
  //   setEnterCode(true);
  // };

  // console.log(enterCode);

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        flexDirection: "column",
        margin: "0 auto",
        width: 200,
        height: 600,
      }}>
      <Typography variant="h6" color="#212121">
        Registration
      </Typography>
      <Formik
        initialValues={{ email: "", pass: "", short: "", name: "" }}
        onSubmit={(values) =>
          register({
            email: values.email,
            pass: values.pass,
            short: values.short,
            name: values.name,
          })
        }>
        {({ errors, handleChange, handleSubmit, values }) => (
          <form method="POST" onSubmit={handleSubmit}>
            <TextField
              name="email"
              id="email"
              label="Email"
              variant="standard"
              onChange={handleChange}
              value={values.email}
            />
            <TextField
              name="pass"
              type="password"
              id="pass"
              label="Pass"
              variant="standard"
              onChange={handleChange}
              value={values.pass}
            />
            <TextField
              name="short"
              type="text"
              id="short"
              label="Short ID"
              variant="standard"
              onChange={handleChange}
              value={values.short}
            />
            <TextField
              name="name"
              type="name"
              id="name"
              label="name"
              variant="standard"
              onChange={handleChange}
              value={values.name}
            />

            <Button
              type="submit"
              variant="contained"
              sx={{ width: 200, marginTop: 2 }}>
              Register
            </Button>
          </form>
        )}
      </Formik>
      <Box sx={{ marginTop: "20px", textAlign: "center" }}>
        <Typography>You have one Account?</Typography>
        <Link to="/login">
          <Typography>Log In!</Typography>
        </Link>
      </Box>
    </Box>
  );
};

export default Reg;
