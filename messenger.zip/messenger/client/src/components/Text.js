import { Box, Typography } from "@mui/material";

const Text = (props) => {
  return (
    <Box>
      <Typography
        sx={{
          color: "rgb(91, 96, 107)",
          marginLeft: "14px",
          fontSize: "16px",
          marginTop: "14px",
        }}>
        {props.text}
      </Typography>
    </Box>
  );
};
export default Text;
