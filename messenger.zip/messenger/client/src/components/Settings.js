import { Box, Button, Modal, TextField } from "@mui/material";
import { FiSettings } from "react-icons/fi";
import { FaUserCircle } from "react-icons/fa";
import { useState } from "react";
import { Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { upload } from "../actions/upload";
import Avatar from "../components/Ava";
import { update } from "../actions/user";

const Settings = () => {
  const dispatch = useDispatch();
  const DOMEN = "http://localhost:5001/";
  const uploads = useSelector((state) => state.upload);
  const [avatar] = useState(localStorage.getItem("avatar"));
  const [name] = useState(localStorage.getItem("name"));

  const [modal, setModal] = useState(false);
  const handleOpen = () => {
    setModal(true);
  };
  const handleClose = () => {
    setModal(false);
  };

  const onChangeAvatar = (e) => {
    let formData = new FormData();
    formData.append("image", e.target.files[0]);
    dispatch(upload({ formData }));
  };
  return (
    <Box
      sx={{
        color: "#B5BFD6",
        transition: "all 0.2s ease",
        "&:hover": {
          color: "#fff",
          cursor: "pointer",
        },
      }}>
      <Modal
        open={modal}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description">
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 500,
            bgcolor: "#272832",
            border: "2px solid #000",
            boxSizing: "border-box",
            borderRadius: "7px",
            boxShadow: 70,
            p: 4,
            display: "flex",
          }}>
          <Box>
            {uploads?.imagesData ? (
              <Avatar link={DOMEN + uploads?.imagesData} size={100} />
            ) : avatar ? (
              <Avatar link={DOMEN + avatar} size={100} />
            ) : (
              <FaUserCircle size={100} color="#b5bfd6" />
            )}
          </Box>
          <Box sx={{ marginLeft: "20px" }}>
            <Formik
              initialValues={{ name: name, avatar: "" }}
              onSubmit={(values) => {
                if (values.name !== "") {
                  console.log(uploads.imagesData);
                  update({ name: values.name, avatar: uploads.imagesData });
                  handleClose();
                }
              }}>
              {({ handleChange, handleSubmit, values }) => (
                <form method="POST" onSubmit={handleSubmit}>
                  <input
                    type="text"
                    value={values.name}
                    id="name"
                    onChange={handleChange}
                    sx={{ width: "200px", height: "30px" }}
                  />
                  <input
                    accept="image/*"
                    type="file"
                    onChange={onChangeAvatar}></input>
                  <Button
                    type="submit"
                    variant="contained"
                    sx={{
                      marginTop: "10px",
                      backgroundColor: "#212121",
                      width: "150px",
                    }}>
                    Save
                  </Button>
                </form>
              )}
            </Formik>
          </Box>
        </Box>
      </Modal>
      <FiSettings size={40} onClick={handleOpen} />
    </Box>
  );
};

export default Settings;
