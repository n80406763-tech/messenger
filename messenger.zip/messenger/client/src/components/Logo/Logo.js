import { Box } from '@mui/material';
import logo from './logo.png';

const Logo = () => {
  return (
    <Box>
      <img src={logo} alt="logo" width={40} />
    </Box>
  );
};

export default Logo;
