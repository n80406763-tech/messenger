import * as api from "../api/index.js";

export const getContactsList = (formData) => async (dispath) => {
  try {
    const token = localStorage.getItem("token");
    formData = { token };

    const { data } = await api.contactsListAPI(formData);

    dispath({ type: "CONTACTS_LIST", data });
  } catch (e) {
    console.log("Error:", e);
  }
};
export const createContact = (formData) => async (dispath) => {
  try {
    const token = localStorage.getItem("token");
    formData = { ...formData, token };
    console.log(formData);
    await api.contactCreateAPI(formData);
    const { data } = await api.contactsListAPI(formData);

    dispath({ type: "CONTACTS_LIST", data });
  } catch (e) {
    console.log("Error:", e);
  }
};
