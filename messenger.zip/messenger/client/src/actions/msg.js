import * as api from "../api/index.js";

export const getMsgList = (formData) => async (dispath) => {
  try {
    const token = localStorage.getItem("token");
    formData = { ...formData, token };

    const { data } = await api.msgListAPI(formData);

    dispath({ type: "MSG_LIST", data });
  } catch (e) {
    console.log("Error:", e);
  }
};

export const createMsg = (formData) => async (dispath) => {
  try {
    const token = localStorage.getItem("token");
    formData = { ...formData, token };

    await api.msgCreateAPI(formData);
    const { data } = await api.msgListAPI(formData);

    dispath({ type: "MSG_LIST", data });
  } catch (e) {
    console.log("Error:", e);
  }
};
