import * as api from "../api/index.js";

export const upload = (imagesData) => async (dispatch) => {
  try {
    const { data } = await api.uploadAPI(imagesData.formData);

    console.log(data);
    dispatch({ type: "UPLOAD_IMAGE", link: data.link });
  } catch (e) {
    console.log("Error:", e);
  }
};
