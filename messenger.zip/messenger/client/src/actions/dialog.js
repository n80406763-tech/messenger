import * as api from "../api/index.js";

export const getDialogsList = (formData) => async (dispath) => {
  try {
    const token = localStorage.getItem("token");
    formData = { token };

    const { data } = await api.dialogsListAPI(formData);

    dispath({ type: "DIALOGS_LIST", data });
  } catch (e) {
    console.log("Error:", e);
  }
};
export const createDialog = async (formData, navigate) => {
  try {
    const token = localStorage.getItem("token");
    formData = { ...formData, token };

    const { data } = await api.dialogsCreateAPI(formData);

    navigate("/msg/" + data.id);
    // dispath({ type: "DIALOGS_LIST", data });
  } catch (e) {
    console.log("Error:", e);
  }
};
