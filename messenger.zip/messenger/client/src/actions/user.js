import * as api from "../api/index.js";

export const register = async (formData) => {
  try {
    const { data } = await api.regAPI(formData);
    localStorage.setItem("token", data.token);
    localStorage.setItem("name", data.name);

    window.location.replace("/");
  } catch (e) {
    console.log("Error:", e);
  }
};

export const login = async (formData) => {
  try {
    const { data } = await api.loginAPI(formData);
    if (data.token !== "undefined") {
      console.log(data.token);
      localStorage.setItem("token", data.token);
      localStorage.setItem("avatar", data.avatar);
      localStorage.setItem("name", data.name);
      window.location.replace("/");
    }
  } catch (e) {
    console.log("Error:", e);
  }
};

export const search = (formData) => async (dispath) => {
  try {
    const token = localStorage.getItem("token");
    formData = { ...formData, token };

    const { data } = await api.searchAPI(formData);

    dispath({ type: "USER_SEARCH", data });
  } catch (e) {
    console.log("Error:", e);
  }
};

export const update = async (formData) => {
  try {
    const token = localStorage.getItem("token");
    formData = { ...formData, token };
    localStorage.setItem("avatar", formData.avatar);
    localStorage.setItem("name", formData.name);
    console.log(formData);
    await api.updateAPI(formData);
  } catch (e) {
    console.log("Error:", e);
  }
};
